/*********************************************************************************
*  WEB322: Assignment 3
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy. 
*  No part of this assignment has been copied manually or electronically from any other source
*  (including web sites) or distributed to other students.
* 
*  Name: TRACY NGUYEN Student ID: 127270171 Date: OCTOBER 2018
*
*  Online (Heroku) URL:  
*
***************************************************************************/

var employees;
var departments;
var empMgr = [];

const fs = require('fs');

function initialize() {
    return new Promise(function (resolve, reject) {
        try {
            fs.readFile('./data/employees.json', function (err, data) {
                if (!err) {
                    employees = JSON.parse(data);
                }
            });
            fs.readFile('./data/departments.json', function (err, data) {
                if (!err) {
                    departments = JSON.parse(data);
                }
            });
        }
        catch (a) {
            reject('unable to read file');
        }
    });

}

function getAllEmployees() {
    return new Promise(function (resolve, reject) {

        if (employees.length == 0) {
            reject('Insufficient number of employees!');
        }

        else {
            resolve(employees);
        }
    });

}

function getManagers() {
    return new Promise(function (resolve, reject) {

        for (var i = 0; i < employees.length; i++) {
            if (employees[i].isManager == true) {
                empMgr.push(employees[i]);
            }
        }

        if (empMgr.length == 0) {
            reject('No results returned!');
        }

        else {
            resolve(empMgr);
        }
    });
}

function getDepartments() {
    return new Promise(function (resolve, reject) {
        if (departments.length == 0) {
            reject('Insufficient number of departments!');
        }

        else {
            resolve(departments);
        }
    });

}


// ----------------------------------------------------

function addEmployee(employeeData) {

    employeesData.employeeNum = employees.length + 1;

    if (typeof employeeData.isManager != "undefined") {
        employeeData.isManager = true;
    }

    else {
        employeeData.isManager = false;
    }

    return new Promise(function (resolve, reject) {
        employees.push(employeeData);
        resolve(employees);
    });
}

function getEmployeesByStatus(status) {
    return new Promise(function (resolve, reject) {
        var statusArr;

        for (var i = 0; i < employees.length; i++) {
            if (employees[i].status == status) {
                statusArr.push(employees[i].status);
            }
        }

        if (statusArr.length == 0) {
            reject('No results');
        }
        else {

            resolve(statusArr);
        }
    });
}

function getEmployeesByDepartment(department) {
    return new Promise(function (resolve, reject) {
        var deptArr;

        if (department > 7 || department < 1) {
            reject('Error! Department does not exist.');
        }

        else {
            for (var i = 0; i < employees.length; i++) {
                if (employees[i].department == department) {
                    deptArr.push(employees[i].department);
                }
            }
        }

        if (deptArr.length == 0) {
            reject('No results');
        }
        else {

            resolve(deptArr);
        }
    });
}

function getEmployeesByManager(manager) {
    return new Promise(function (resolve, reject) {
        var mgrArr = [];

        if (manager >= 1 && manager <= 30) {
            for (var i = 0; i < employees.length; i++) {
                if (employees[i].employeeManagerNum == manager) {
                    deptArr.push(employees[i].employeeManagerNum);
                }
            }
        }

        if (mgrArr.length == 0) {
            reject('No results');
        }
        else {

            resolve(mgrArr);
        }
    });
}

function getEmployeeByNum(num) {
    return new Promise(function (resolve, reject) {

        var empName = employees[num - 1].firstName + ' ' + employees[i].lastName;

        if (typeof empName == 'undefined') {
            reject('No results');
        }

        else {
            resolve(empName);
        }
    });
}


module.exports = {
    initialize: initialize,
    getAllEmployees: getAllEmployees,
    getManagers: getManagers,
    getDepartments: getDepartments,
    addEmployee: addEmployee,
    getEmployeesByStatus: getEmployeesByStatus,
    getEmployeesByDepartment: getEmployeesByDepartment,
    getEmployeesByManager: getEmployeesByManager,
    getEmployeeByNum: getEmployeeByNum
}