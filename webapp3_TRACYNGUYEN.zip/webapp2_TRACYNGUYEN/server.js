/*********************************************************************************
*  WEB322: Assignment 3
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy. 
*  No part of this assignment has been copied manually or electronically from any other source
*  (including web sites) or distributed to other students.
* 
*  Name: TRACY NGUYEN Student ID: 127270171 Date: OCTOBER 2018
*
*  Online (Heroku) URL:  
*
***************************************************************************/

const express = require('express');
const appEXP = express();

const multer = require('multer');
const storage = multer.diskStorage({
  destination: "./public/images/uploaded",
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

const fs = require('fs');
const bodyParser = require('body-parser');
var dataSrv = require('./data-service.js');
appEXP.use(express.static(__dirname + '/public'));

const path = require("path");

var HTTP_PORT = process.env.PORT || 8080;

function onHttpStart() {
  console.log('Express http server listening on: ' + HTTP_PORT);
}

// Assignment 2

appEXP.get('/', function (req, res) {
  res.sendFile(__dirname + '/views/home.html');
});

appEXP.get('/about', function (req, res) {
  res.sendFile(__dirname + '/views/about.html');
});


appEXP.get('/employees', function (req, res) {

  if (req.query.status) {
    dataSrv.getEmployeesByStatus(req.query.status).then(function (data) {
      res.json(data);
    })
      .catch(function (err) {
        res.json(err);
      })
  }

  else if (req.query.department) {
    dataSrv.getEmployeesByDepartment(req.query.department).then(function (data) {
      res.json(data);
    })
      .catch(function (err) {
        res.json(err);
      })
  }

  else if (req.query.employeeManagerNum) {
    dataSrv.getEmployeesByManager(req.query.employeeManagerNum).then(function (data) {
      res.json(data);
    })
      .catch(function (err) {
        res.json(err);
      })
  }

  else if (req.query.num) {
    dataSrv.getEmployeeByNum(req.query.num).then(function (data) {
      res.json(data);
    })
      .catch(function (err) {
        res.json(err);
      })
  }

  else {
    dataSrv.getAllEmployees().then(function (data) {
      res.json(data);
    })
      .catch(function (err) {
        res.json(err);
      })
  }
});

appEXP.get('/managers', function (req, res) {
  dataSrv.getManagers().then((data) => {
    res.json(data);
  })
    .catch((err) => {
      res.json(err);
    })
});

appEXP.get('/departments', function (req, res) {
  dataSrv.getDepartments().then(function (data) {
    res.json(data);
  })
    .catch(function (err) {
      res.json({ message: err });
    })
});



//Assignment 3

appEXP.get('/employees/add', function (req, res) {
  res.sendFile(__dirname + '/views/addEmployee.html')
});

appEXP.get('/images/add', function (req, res) {
  res.sendFile(__dirname + '/views/addImage.html');
});

appEXP.get('/images', function (req, res) {

  const imgPathname = '/public/images/uploaded';

  fs.readdir(path.join(__dirname, imgPathname), function (err, items) {
    
    var imgArr = { images : []};

    for (var i = 0; i < items.length; i++) {
      imgArr.images.push(items[i]);
    }

    res.json(imgArr);

  });
});

appEXP.use(bodyParser.urlencoded({ extended: true }));

appEXP.post('/employees/add', function (req, res) {
  dataSrv.addEmployee(req.body).then(
    function () {
      res.redirect('/employees');
    });
});

appEXP.post("/images/add", upload.single("imageFile"), (req, res) => {
  res.redirect("/images");
});

dataSrv.initialize().then(appEXP.listen(HTTP_PORT, onHttpStart));


appEXP.use(function (req, res) {
  res.status(404).send('Error! 404 Page Not Found.');
});
