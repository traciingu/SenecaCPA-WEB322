/*********************************************************************************
*  WEB322: Assignment 1
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy. 
*  No part of this assignment has been copied manually or electronically from any other source
*  (including web sites) or distributed to other students.
* 
*  Name: TRACY NGUYEN Student ID: 127270171 Date: SEPTEMBER 2018
*
*  Online (Heroku) URL:  https://salty-woodland-80837.herokuapp.com/ 
*
***************************************************************************/

var employees;
var departments;
var empMgr = [];

const fs = require('fs');

function initialize() {
    return new Promise(function (resolve, reject) {
        try {
            fs.readFile('./data/employees.json', function (err, data) {
                if (!err) {
                    employees = JSON.parse(data);
                }
            });
            fs.readFile('./data/departments.json', function (err, data) {
                if (!err) {
                    departments = JSON.parse(data);
                }
            });
        }
        catch (a) {
            reject('unable to read file');
        }
    });

}

function getAllEmployees() {
    return new Promise(function (resolve, reject) {

        if (employees.length == 0) {
            reject('Insufficient number of employees!');
        }

        else {
            resolve(employees);
        }
    });

}

function getManagers() {
    return new Promise(function (resolve, reject) {

            for (var i = 0; i < employees.length; i++) {
                if (employees[i].isManager == true) {
                    empMgr.push(employees[i]);
                }
            }

            if (empMgr.length == 0) {
                reject('No results returned!');
            }

            else {
                resolve(empMgr);
            }
    });
}

function getDepartments() {
    return new Promise(function (resolve, reject) {
        if (departments.length == 0) {
            reject('Insufficient number of departments!');
        }

        else {
            resolve(departments);
        }
    });

}


module.exports = {
    initialize: initialize,
    getAllEmployees: getAllEmployees,
    getManagers: getManagers,
    getDepartments: getDepartments
}

// ----------------------------------------------------



// module.exports.getAllEmployees = function(){
//     var arryAllEmployees=[];
//     return new Promise(function(resolve,reject){
//         for (var i = 0; i < employees.length; i++) {
//             arryAllEmployees.push(employees[i]);
//         }
//         if (arryAllEmployees.length == 0){
//             reject("No Result Returned!!!");
//         }
//     resolve(arryAllEmployees);
//     })
// }



// module.exports.getManagers = function() {
//     var arryGetManagers = [];
//     return new Promise(function(resolve,reject){
//         if(employees.length == 0){
//             reject("No Result Returned!!!");
//         }else{
//             for (var q = 0; q < employees.length; q++) {
//                  if (employees[q].isManager == true) {
//                     arryGetManagers.push(employees[q]);       
//                  }
//             }
//             if (arryGetManagers.length == 0) {
//                      reject("No Result Returned!!!");
//              }
//         }
//         resolve(arryGetManagers);
//      });
// }

// module.exports.getDepartments = function() {
//     var arryGetDepartments = [];
//     return new Promise(function(resolve,reject){
//         if(employees.length == 0){
//             reject("No Result Returned!!!");
//         }else{
//             for (var v = 0; v < departments.length; v++) {
//                 arryGetDepartments.push(departments[v]);       
//             }
//             if (arryGetDepartments.length == 0) {
//                 reject("No Result Return!!!");
//             }
//         }
//     resolve(arryGetDepartments);
//     });
// }
