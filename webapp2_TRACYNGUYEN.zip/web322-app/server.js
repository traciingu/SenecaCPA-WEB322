/*********************************************************************************
*  WEB322: Assignment 1
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy. 
*  No part of this assignment has been copied manually or electronically from any other source
*  (including web sites) or distributed to other students.
* 
*  Name: TRACY NGUYEN Student ID: 127270171 Date: SEPTEMBER 2018
*
*  Online (Heroku) URL:  https://salty-woodland-80837.herokuapp.com/ 
*
***************************************************************************/

var express = require('express');
var app = express();
var dataSrv = require('./data-service.js');

app.use(express.static(__dirname + '/public'));

var HTTP_PORT = process.env.PORT || 8080;

function onHttpStart() {
  console.log('Express http server listening on: ' + HTTP_PORT);
}

app.get('/', function(req, res){
   res.sendFile(__dirname + '/views/home.html');
});

app.get('/about', function(req, res){
  res.sendFile(__dirname + '/views/about.html');
});


app.get('/employees', function(req, res) {
  dataSrv.getAllEmployees().then(function(data) {
    res.json(data);
  })
  .catch(function(err) {
    res.json(err);
  })
});

app.get('/managers', function(req, res) {
  dataSrv.getManagers().then((data) => {
    res.json(data);
  })
  .catch((err) => {
    res.json(err);
  })
});

app.get('/departments', function(req, res) {
  dataSrv.getDepartments().then(function(data) {
    res.json(data);
  })
  .catch(function(err) {
    res.json({message: err});
  })
});


dataSrv.initialize().then(app.listen(HTTP_PORT, onHttpStart));


app.use(function (req, res) {
  res.status(404).send('Error! 404 Page Not Found.');
});