/*********************************************************************************
*  WEB322: Assignment 6
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy. 
*  No part of this assignment has been copied manually or electronically from any other source
*  (including web sites) or distributed to other students.
* 
*  Name: TRACY NGUYEN Student ID: 127270171 Date: DEC 2018
*
*  Online (Heroku) URL:  https://assignment6-tnguyen.herokuapp.com/ 
*
***************************************************************************/
const Sequelize = require('sequelize');

var sequelize = new Sequelize('d9g64534a29tb', 'mzltmnpnlefvzd', '823eb9ae25db028f26bd5e069c1b22ea43e36252705939ed828842dd69752ee8', {
    host: "ec2-54-227-249-201.compute-1.amazonaws.com",
    dialect: 'postgres',
    port: 5432,
    dialectOptions: {
    ssl: true
    }
    });

var Employee = sequelize.define("Employee",{

    employeeNum:
     {
        type:Sequelize.INTEGER,
        primaryKey:true,
        autoIncrement: true
     },

    firstName:Sequelize.STRING,
    lastName:Sequelize.STRING,
    email:Sequelize.STRING,
    SSN:Sequelize.STRING,
    addressStreet:Sequelize.STRING,
    addressCity:Sequelize.STRING,
    addressState:Sequelize.STRING,
    addressPostal:Sequelize.STRING,
    maritalStatus:Sequelize.STRING,
    isManager:Sequelize.BOOLEAN,
    employeeManagerNum:Sequelize.INTEGER,
    status:Sequelize.STRING,
    hireDate:Sequelize.STRING

    });

    var Department = sequelize.define("Department",{
     
            departmentId:
            {
                type:Sequelize.INTEGER,
                primaryKey:true,
                autoIncrement:true
            },
            
        departmentName:Sequelize.STRING
});

    
Department.hasMany(Employee, {foreignKey: 'department'});



module.exports.initialize = function () {
    return new Promise(function (resolve, reject) {
        sequelize.sync().then(function () {
            resolve();
        }).catch(function (err) {
            reject(`Unable to sync the database! ${err}`);
        });
    });
};


module.exports.getAllEmployees = function()
{
        
        return new Promise(function(resolve, reject) {
            Employee.findAll().then(function(data){
                resolve(data);
            }).catch(function(err)
            {
                    reject("no result returned!")
            });
        
        });
           
    
};


module.exports.getEmployeeByNum = function (empNum) {


    
      return new Promise(function (resolve,reject)
      {
          Employee.findAll({
              where: {employeeNum: empNum}
          }).then(function(data){
             
            resolve(data[0]);

        }).catch(function(err){
            reject ("no results returned");
        });
        
      });
       
  };


module.exports.getEmployeesByStatus=function(status){
    
    return  new Promise(function(resolve, reject) 
    {

        Employee.findAll({
            order: ["employeeNum"],
            where: {
                status: status
            }
        }).then(function(data){
            resolve("Success!");
        }).catch(function(err){
        reject("no results returned");
        });
    });
      
};
    

module.exports.getEmployeesByDepartment = function (department) {

    return  new Promise(function(resolve, reject) 
    {
        Employee.findAll({
            order: ["employeeNum"],
            where: {
                department: department
            }
        }).then(function(data){
            resolve("Success!");
        }).catch((err)=>{
            reject("no results returned");
        });

    });
};


module.exports.getEmployeesByManager = function (manager) {
   
    return  new Promise(function(resolve, reject) 
    {
        Employee.findAll({
            order: ["employeeNum"],
            where: {
                employeeManagerNum: manager
            }
        }).then(function(data){
            resolve("Success!");
        }).catch((err)=>{
            reject("no results returned");
        });

    });
    
};





/* module.exports.getManagers = function () {
    return new Promise(function (resolve, reject) {
        Employee.findAll({
            where: {
                isManager: true
            }
        }).then((data) => {
            resolve(data);
        }).catch((err) => {
            reject("no results returned");
        });

    });
}; */

module.exports.getDepartments = function() 
{
    return  new Promise(function(resolve, reject) 
    {
        Department.findAll({
        where: {}
        }).then(function(data){
            resolve(data);
        }).catch(function(err){
            reject("no results returned");
        });

    });
};


module.exports.addEmployee = function(employeeData){

    employeeData.isManager = (employeeData.isManager) ? true : false;

    for (let x in employeeData)
     {
        if(employeeData[x] == "")
        {
            employeeData[x] = null;
        }
    }
    return  new Promise(function(resolve, reject) 
        {
            
            Employee.create({
                employeeNum: employeeData.employeeNum,
                firstName: employeeData.firstName,
                last_name: employeeData.last_name,
                email: employeeData.email,
                SSN: employeeData.SSN,
                addressStreet: employeeData.addressStreet,
                addresCity: employeeData.addresCity,
                isManager: employeeData.isManager,
                addressState: employeeData.addressState,
                addressPostal: employeeData.addressPostal,
                employeeManagerNum: employeeData.employeeManagerNum,
                status: employeeData.status,
                hireDate: employeeData.hireDate
            
            }).then(function(){

                resolve("Success!");
                
            }).catch(function(){
            reject("unable to create employee.");
            });
        });
 };



module.exports.updateEmployee = function (employeeData) {

    employeeData.isManager = (employeeData.isManager) ? true : false;

    for (let i in employeeData) {
        if (employeeData[i] == "") {
            employeeData[i] = null;
        }
    }
    return  new Promise(function(resolve, reject) 
    {
        Employee.update(employeeData,{
           
            
                where: {employeeNum: employeeData.employeeNum}
              })
                .then(() => {
                  resolve();
                })
                .catch(() => {
                  reject("unable to update employee");
        });

    });
};


module.exports.addDepartment = (departmentData) =>{
    for (let x in departmentData){
        if (departmentData == ""){
            departmentData = null;
        }
    }
    
    return new Promise(function(resolve, reject){
        Department.create(departmentData).then(function(data){
            resolve(data);
        }).catch(function(){
            reject("unable to create department");
        });
    });
};

module.exports.updateDepartment = function(departmentData){

    for (let x in departmentData){
        if (departmentData == ""){
            departmentData = null;
        }
    }

    return new Promise(function(resolve, reject){
        Department.update(departmentData,{
            where: {
                departmentId: departmentData.departmentId
            }
        }).then(function(){
            resolve();
        }).catch(function(err){
            reject("unable to update department");
        });
    });
};

module.exports.getDepartmentById = function(id){
    return new Promise(function(resolve, reject){
        Department.findAll({
            where: {
                departmentId: id
            }
        }).then(function(data){
            resolve(data[0]);
        }).catch(function(err){
            reject("no results returned");
        });
    });
};


module.exports.deleteDepartmentById = function(id){

    return new Promise((resolve, reject)=>{
        Department.destroy({
            where:
             {
                departmentId:id
             }
        }).then(function(){
            resolve("Destroied!");
        }).catch(function(err){
            reject("Was rejected!");
        });
    });
};

module.exports.deleteEmployeeByNum = function(empNum)
{
    return new Promise((resolve,reject)=>{
        Employee.destroy({
            where: {
                employeeNum: empNum
            }
        }).then(()=>{
            resolve("deleted employee");
        }).catch(()=>{
            reject(`Failed to destroy employee by ID`);
        });
    });

}