/*********************************************************************************
*  WEB322: Assignment 6
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy. 
*  No part of this assignment has been copied manually or electronically from any other source
*  (including web sites) or distributed to other students.
* 
*  Name: TRACY NGUYEN Student ID: 127270171 Date: DEC 2018
*
*  Online (Heroku) URL:  https://assignment6-tnguyen.herokuapp.com/ 
*
***************************************************************************/

const dataServiceAuth=require("./data-service-auth")
const express = require("express");
const app=express();
const path=require("path");
const multer=require("multer");
const fs=require("fs");
const bodyParser=require("body-parser");
var clientSessions = require("client-sessions");
const HTTP_PORT = process.env.PORT || 8080;
const DataService=require("./data-service");
const exhbs=require("express-handlebars");  
app.engine('.hbs',exhbs(
    {
        extname:'.hbs',
        defaultLayout:"main",
        helpers: {       
            navLink: function(url, options){
            return '<li' +
           ((url == app.locals.activeRoute) ? ' class="active" ' : '') +
           '><a href="' + url + '">' + options.fn(this) + '</a></li>';},

           equal: function (lvalue, rvalue, options) {
           if (arguments.length < 3)
           throw new Error("Handlebars Helper equal needs 2 parameters");
           if (lvalue != rvalue) {
           return options.inverse(this);
           } else {
           return options.fn(this); }}  
}

    }));

    app.set('view engine', '.hbs');

    app.use(function(req,res,next){
        let route = req.baseUrl + req.path;
        app.locals.activeRoute = (route == "/") ? "/" : route.replace(/\/$/, "");
        next();
        });

//const destination = "./public/images/uploaded";


app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));


app.use(clientSessions({
    cookieName: "session", 
    secret: "web322_assignment6",
    duration: 3 * 60 * 1000, // 3minutes
    activeDuration: 1000 * 60 
}));

app.use(function(req, res, next) {
    res.locals.session = req.session;
    next();
});  

let ensureLogin = (req, res, next) => {
    if(!req.session.user){
        res.redirect("/login");
    } else {
        next();
    }
};


const storage = multer.diskStorage({
    destination : "./public/images/uploaded",

filename: function (req, file, cb) 
    {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer ({storage:storage});

app.post("/images/add",upload.single("imageFile"),ensureLogin, function (req,res){

    res.redirect("/images");
});

app.get("/images",ensureLogin, (req, res) => {
    
    fs.readdir(path.join(__dirname, "./public/images/uploaded"), function (err, items) {
        res.render('images', {images: items});
    });

});

app.use(bodyParser.urlencoded({extended:true}));

app.post("/employees/add", ensureLogin, (req,res)=>{
DataService.addEmployee(req.body).then(()=>{
        res.redirect("/employees");
    }).catch(function(reason){
        console.log("Error "+reason.message);
    });

});

app.post("/departments/add", ensureLogin, (req,res)=>{
    DataService.addDepartment(req.body).then(()=>{
            res.redirect("/departments");
        }).catch(function(){
            console.log(err);
        });
    
    });

app.post("/employee/update", ensureLogin, (req, res) => { 
    
    DataService.updateEmployee(req.body).then(() => {
      res.redirect("/employees");
    }).catch((err)=>{
    console.log (err);
     })
  });

  app.post("/department/update", ensureLogin, (req, res) => {
    
    DataService.updateDepartment(req.body).then(() => {
      res.redirect("/departments");
    }).catch((err)=>{
    console.log (err);
     })
  });
    
  app.post('/register', (req, res) => {
    dataServiceAuth.registerUser(req.body)
    .then((value) => {
        res.render("register", {successMessage: "User created"});
    }).catch((err) => {
        res.render("register", {errorMessage: err, userName: req.body.userName});
    })
});

app.post('/login', (req, res) => {
    req.body.userAgent = req.get('User-Agent');

    dataServiceAuth.checkUser(req.body)
    .then((user) => {
        req.session.user = {
            userName: user.userName,
            email: user.email,
            loginHistory: user.loginHistory
        }
        res.redirect('/employees');
    }).catch((err) => {
        res.render('login', {errorMessage: err, userName: req.body.userName});
    });
});

app.get("/", function(req,res){
res.render("home");
});

app.get("/about", function(req,res){
    res.render("about");
});

app.get("/login",(req,res)=>{
    res.render("login");
});

app.get("/register",(req,res)=>{
res.render("register");
});

app.get("/logout", (req,res)=>{
    req.session.reset();
    res.redirect("/");
});

app.get('/userHistory', ensureLogin, (req, res) => {
    res.render('userHistory');
});

app.get("/employees/add", ensureLogin, function (req, res) {
DataService.getDepartments().then((data) => {
        res.render("addEmployee", { departments: data });
    }).catch(() => {
        res.render("addEmployee", { departments: [] });
    })
  });

  app.get("/images/add", ensureLogin, function (req, res) {
    //res.render(path.join(__dirname,"/views/addimage"));
   res.render("addImage")
  });

  app.get("/employee/:empNum", ensureLogin, function (req, res) {   
    let viewData = {};
    DataService.getEmployeeByNum(req.params.empNum).then((data) => {
        if (data) {
            viewData.employee = data; 
        } else {
            viewData.employee = null; 
        }
    }).catch(() => {
        viewData.employee = null; 
    }).then(DataService.getDepartments)
        .then((data) => {
            viewData.departments = data; 
            for (let i = 0; i < viewData.departments.length; i++) {
                if (viewData.departments[i].departmentId == viewData.employee.department) {
                    viewData.departments[i].selected = true;
                }
            }
        }).catch(() => {
            viewData.departments = []; 
        }).then(() => {
            if (viewData.employee == null) { 
                res.status(404).send("Employee Not Found");
            } else {
                res.render("employee", { viewData: viewData }); 
            }
        });
  });


  app.get("/department/:departmentId",ensureLogin, function (req, res) {
    DataService.getDepartmentById(req.params.departmentId)
     .then((data) => {
         res.render("department", { department: data });
     })
     .catch((err) => {
        res.status(404).send("Department Not Found");
     })
   });


   app.get("/departments/delete/:departmentId",ensureLogin, function(req,res){
            DataService.deleteDepartmentById(req.params.departmentId).then(function(data){
                res.redirect("/departments");
            }).catch(function(err){
                res.status(500).send("Unable to Remove Deoart / Employee not found"); //fix
            });

   });


   


  app.get("/employees",ensureLogin, function (req, res) {
      
    if (req.query.status) {
      DataService.getEmployeesByStatus(req.query.status)
        .then((data) => {
            if (data.length>0)
          {res.render("employees", {employees: data});}
          else 
          {res.render("employees",{message: "~ No Results ~"});}
        })
        .catch((err) => {
            res.render("employees",{message: "~ No Results ~"});
        })
    }else if (req.query.department) {
        DataService.getEmployeesByDepartment(req.query.department)
          .then((data) => {
            if (data.length>0)
            {res.render("employees", {employees: data});}
            else 
            {res.render("employees",{message: "~ No Results ~"});}
          })
          .catch((err) => {
            res.render("employees",{message: "~ No Results ~"});
          })
      }else if (req.query.manager) {
          
        DataService.getEmployeesByManager(req.query.manager)
          .then((data) => {
            if (data.length>0)
           { res.render("employees", {employees: data});}
            else  
            {res.render("employees",{message: "~ No Results ~"});}
          })
          .catch((err) => {
            res.render("employees",{message: "~ No Results ~"});
          })
      }else {
        DataService.getAllEmployees()
          .then((data) => {
              if(data.length>0)
              {
            res.render("employees", {employees: data});
              }
            else {res.render("employees",{message: "~ No Results ~"});}
          })
          .catch((err) => {
            res.render("employees",{ message: "~ No Results ~"});
          })
      }
  });


app.get("/employees",ensureLogin, function(req,res){

    DataService.getAllEmployees().then(function(data){
        if(data.length > 0){res.render("employees",{employees:data});}
        else{res.render("employees",{ message: "~ No Results ~" });}
    }).catch((err)=>{
        res.render("employees",{ message: "~ No Results ~" });
    })
});

app.get("/managers", (req, res) => {
    DataService.getManagers().then(function(data){
        res.json(data);
    }).catch((err)=>{
        res.json(err.message);
    })
});

app.get("/departments/add", ensureLogin, function (req, res) {
    res.render("addDepartment");
  });


app.get("/departments",ensureLogin, (req, res) => {
    DataService.getDepartments().then(function(data){
        if(data.length > 0)
            {
                res.render("departments", {departments: data});
            }

        else{res.render("departments",{message: "~ No Results ~"});}

    }).catch((err)=>{
        res.render("departments",{message: "~ No Results ~"});
    })
});

app.get('/employees/delete/:empNum',ensureLogin, (req, res) => {
    DataService.deleteEmployeeByNum(req.params.empNum).then(() => {
        res.redirect('/employees');
    }).catch(() => {
        res.status(500).send(`Unable to Remove Employee / Employee not found`);
    });
});


DataService.initialize().then(dataServiceAuth.initialize()).then(()=>
{
    
    app.listen(HTTP_PORT, () => {
        console.log("express server listening on " + HTTP_PORT);
    });
}).catch((err) => {
    res.status(500).send("Unable to Update Employee");
    });

    